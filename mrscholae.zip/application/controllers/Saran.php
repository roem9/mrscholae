<?php
class Saran extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model("Arab_model", "arab");
    }

    public function index(){
        $data['title'] = "Kritik & Saran";
        
        $this->load->view("templates/header", $data);
        $this->load->view("page/saran", $data);
        $this->load->view("templates/footer", $data);
    }

    public function add_saran(){
        $this->arab->add_saran();
        
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Terima Kasih. Kritik & Saran Anda telah kami terima<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            
        redirect($_SERVER['HTTP_REFERER']);
    }
}