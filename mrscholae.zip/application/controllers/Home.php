<?php
class Home extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model('Arab_model', "arab");
        // if($this->session->userdata('status') != "login"){
        //     $this->session->set_flashdata('login', 'Maaf, Anda harus login terlebih dahulu');
		// 	redirect(base_url("login"));
		// }
    }

    public function index(){
        $data['title'] = "Mufrodat";
        
        $data['tema'] = $this->arab->get_all_tema();
        
        $this->load->view("templates/header", $data);
        $this->load->view("page/tema", $data);
        $this->load->view("templates/footer", $data);
    }
}