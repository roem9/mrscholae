<?php 

class Tentang extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
    }

    public function index(){

        $data['title'] = "Tentang";
        
        $this->load->view("templates/header", $data);
        $this->load->view("page/cara", $data);
        $this->load->view("templates/footer", $data);
    }

    public function simbol(){

        $data['title'] = "Simbol";
        
        $this->load->view("templates/header", $data);
        $this->load->view("page/simbol", $data);
        $this->load->view("templates/footer", $data);
    }
}