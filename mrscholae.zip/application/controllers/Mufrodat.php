<?php

class Mufrodat extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model('Arab_model', "arab");
    }

    public function bagian($id){
        $tema = $this->arab->get_data_tema($id);

        $data['title'] = $tema['tema'];
        
        $data['mufrodat'] = $this->arab->get_all_mufrodat_by_id($id);
        
        $this->load->view("templates/header", $data);
        $this->load->view("page/mufrodat", $data);
        $this->load->view("templates/footer", $data);
    }

    public function cetak($id){
        
        $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => 'A4-P', 'margin_top' => '10', 'margin_left' => '25', 'margin_right' => '25', 'margin_bottom' => '10']);

        $tema = $this->arab->get_data_tema($id);

        $cek['title'] = $tema['tema'];
        
        $cek['mufrodat'] = $this->arab->get_all_mufrodat_by_id($id);
        
        // $this->load->view("templates/header-login", $data);
        
        // $data = "Hello World";
        $mpdf->autoScriptToLang = true;
        $mpdf->autoLangToFont = true;
		$data = $this->load->view("pdf/mufrodat-pertema", $cek, TRUE);
        $mpdf->WriteHTML($data);
		$mpdf->Output("{$tema['tema']}.pdf", "I");
    }

    public function get_data_kalimat(){
        $id = $this->input->post("id");
        $data = $this->arab->get_data_kalimat($id);
        echo json_encode($data);
    }

    public function get_data_kata(){
        $id = $this->input->post("id");
        $data = $this->arab->get_data_kata($id);
        echo json_encode($data);
    }
}