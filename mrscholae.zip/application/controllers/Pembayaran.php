<?php 
class Pembayaran extends CI_CONTROLLER {
    public function __construct(){
        parent::__construct();
        $this->load->model("Arab_model");
        if($this->session->userdata('status') != "login"){
            $this->session->set_flashdata('login', 'Maaf, Anda harus login terlebih dahulu');
			redirect(base_url("login/user"));
		}
    }

    public function index(){

        $data['title'] = "Pembayaran";

        $id = $this->session->userdata("id");

        $data['pembelian'] = $this->Arab_model->get_all_pembelian_by_id_user($id);

        // var_dump($data);
        
        $this->load->view("templates/header-user", $data);
        $this->load->view("user/pembayaran", $data);
        $this->load->view("templates/footer-user", $data);
    }

    // hapus
        public function hapus_pembelian_by_id(){
            $id = $this->input->post("id_pembelian");
            $this->Arab_model->hapus_pembelian_by_id($id);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil membatalkan pembayaran<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect(base_url("pembayaran"));
        }
    // hapus

    // add
        public function edit_pembelian_by_id(){
            $foto = $this->add_foto();
            if($foto){
                $id = $this->input->post("id_pembelian");
                $this->Arab_model->edit_pembelian_by_id($id, $foto);
                $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil mengupload bukti pembayaran, silahkan menunggu konfirmasi.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                redirect(base_url("pembayaran"));
            } else {
                $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Gagal mengupload bukti pembbayaran<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                redirect(base_url("pembayaran"));
            }
        }

    // other function
        public function add_foto(){
            if (isset($_FILES['foto']['name']) && $_FILES['foto']['name'] != '') {
                unset($config);
                $configFoto['upload_path'] = './assets/img';
                $configFoto['max_size'] = '6000';
                $configFoto['allowed_types'] = 'png|jpg|jpeg|img';
                $configFoto['overwrite'] = TRUE;
                $configFoto['remove_spaces'] = TRUE;
                $foto_name = $this->input->post("id_pembelian");
                $configFoto['file_name'] = $foto_name;
                
                // return $configFoto;
                $this->load->library('upload', $configFoto);
                $this->upload->initialize($configFoto);
                if(!$this->upload->do_upload('foto')) {
                    echo $this->upload->display_errors();
                }else{
                    $fotoDetails = $this->upload->data();
                    $data['foto_name']= $configCover['file_name'];
                    $data['foto_detail'] = $fotoDetails;
                    return $fotoDetails['orig_name'];
                }

            }
        }
}