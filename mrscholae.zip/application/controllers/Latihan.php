<?php 
class Latihan extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model("Latihan_model");
        if($this->session->userdata('status') != "login"){
            $this->session->set_flashdata('login', 'Maaf, Anda harus login terlebih dahulu');
			redirect(base_url("login"));
        }
    }

    public function latihan_mufrodat(){
        $id = $this->session->userdata('id');

        $this->Latihan_model->add_latihan_mufrodat();

        redirect('kosakata');
    }

    public function latihan1(){
        $this->Latihan_model->add_latihan();
        $this->Latihan_model->add_materi();
        
        redirect('level1/materi/pertama');
    }

    public function latihan2(){
        $this->Latihan_model->add_latihan();
        $this->Latihan_model->add_materi();
        
        redirect('level1/materi/kedua');
    }

    public function latihan3(){
        $id = $this->session->userdata('id');

        $this->Latihan_model->add_latihan();

        $latihan = COUNT($this->Latihan_model->get_all_latihan_by_id_materi_id_user("3", $id));
        
        if($latihan == '15'){
            $this->Latihan_model->add_materi();
        }

        redirect('level1/materi/ketiga');
    }

    public function latihan4(){
        $id = $this->session->userdata('id');

        $this->Latihan_model->add_latihan();

        $latihan = COUNT($this->Latihan_model->get_all_latihan_by_id_materi_id_user("4", $id));
        
        if($latihan == '5'){
            $this->Latihan_model->add_materi();
        }

        redirect('level1/materi/keempat');
    }
}