<?php
class Login extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model('Login_model');
        $this->load->model('Arab_model');
    }

    public function index(){
        $data['header'] = 'Login User';
        $data['title'] = 'Login User';

        $this->load->view("templates/header-login", $data);
        $this->load->view("login/login-user");
        $this->load->view("templates/footer");
    }

    public function user(){
        $data['header'] = 'Login';
        $data['title'] = 'Login';

        $this->load->view("templates/header-login", $data);
        $this->load->view("login/login");
        $this->load->view("templates/footer");
    }

    public function cekLogin(){
        $cek = 0;

        if($this->input->post("username") == "mrscholae" && $this->input->post("password") == "bismillah"){
            $cek = 1;
        };

		if($cek > 0){
 
			$data_session = array(
				'id' => $data['nip'],
                'status' => "login",
				);
 
			$this->session->set_userdata($data_session);
 
			redirect(base_url("admin"));
 
		}else{
            $this->session->set_flashdata('login', 'Maaf, kombinasi username dan password salah');
			redirect(base_url("login"));
		}

    }
    
    public function cek_login_user(){
        $cek = $this->Login_model->cek_login_user();

		if($cek){
            $this->Arab_model->edit_reset_password_by_id($cek['id_user'], "0");
			$data_session = array(
                'id' => $cek['id_user'],
                'status' => "login"
				);
 
			$this->session->set_userdata($data_session);
			redirect(base_url("daftar/pelajaranku"));
 
		}else{
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Maaf, kombinasi emal dan password salah<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
			redirect(base_url("login"));
		}

    }

    function logout_user(){
        $this->session->sess_destroy();
        redirect(base_url("login"));
    }

    public function lupa_password(){
        $email = $this->input->post("email", TRUE);
        $cek = $this->Arab_model->get_user_by_email($email);
        if($cek){
            // turn reset password to on
            $this->Arab_model->edit_reset_password_by_id($cek['id_user'], "1");
            
            $link = base_url() . "login/resetsandi/" . MD5($cek['id_user']). MD5("kenu") . MD5($cek['nama']);
            $this->load->config('email');
            $this->load->library('email');
            $this->email->set_mailtype("html");

    
            // $id = $this->Agency_model->getLastId();
            // $id_agency = $id['id_agency'] + 1;
    
            $from = $this->config->item('smtp_user');
            $to = $this->input->post('email', true);
            $subject = 'Konfirmasi Reset Sandi';
            $message = '<p style="font-size: 16px"><b>Kepada Yth. Muhammad Rum</b>
                        <p>Kami menerima permintaan untuk mereset sandi Anda. Jika Anda tidak melakukannya, silahkan abaikan email ini. Email ini akan kadaluarsa setelah Anda berhasil login</p>
                        <p>Untuk mereset sandi, Anda dapat mengunjungi link berikut ini : '.$link.'</p>
                        <br><br><br><br><br>
                        
                        <p>Hormat kami, </p>
                        <p>mrscholae<br>';
    
            $this->email->set_newline("\r\n");
            $this->email->from($from);
            $this->email->to($to);
            $this->email->subject($subject);
            $this->email->message($message);
            $this->email->send();
            
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil mengirim link ke email Anda. Silahkan membuka link melalui email Anda<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect("login");
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Gagal mengirim ke email Anda. Karena email Anda belum terdaftar<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect("login");
        }
    }

    public function resetSandi($id){
        $id = explode(MD5("kenu"), $id);

        $cek = $this->Arab_model->get_user_by_id_by_name($id[0], $id[1]);
        if($cek){
            $data['header'] = 'Reset Sandi';
            $data['title'] = 'Reset Sandi';
    
            $data['id'] = $id[0];
    
            $this->load->view("templates/header-login", $data);
            $this->load->view("login/reset-password", $data);
            $this->load->view("templates/footer");
        } else {
            
        $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Maaf link kadaluarsa<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect("login");
        }
    }

    public function reset_password_by_id(){
        $id = $this->input->post("id_user", TRUE);
        $data = $this->Arab_model->get_user_by_id_hash($id);
        $this->Arab_model->edit_password($data['id_user']);
        $this->Arab_model->edit_reset_password_by_id($data['id_user'], "0");
        $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil mereset sandi Anda. Silahkan login menggunakan sandi baru Anda<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
        redirect("login");
    }

    public function registrasi(){
        $data['title'] = "Form Pendaftaran";
    
        $this->load->view("templates/header-login", $data);
        $this->load->view("page/form-pendaftaran", $data);
    }

    public function add_user(){
        $email = $this->input->post("email", TRUE);
        $cek = $this->Arab_model->get_user_by_email($email);
        if($cek){
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Gagal mendaftarkan akun Anda. email Anda sudah digunakan<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $id = $this->Arab_model->get_last_id_user();
            $this->Arab_model->add_user($id);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil mendaftarkan akun Anda<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect("login");
        }
    }
}