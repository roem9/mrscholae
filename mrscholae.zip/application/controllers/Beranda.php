<?php
class Beranda extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model('Arab_model');
        if($this->session->userdata('status') != "login"){
            $this->session->set_flashdata('login', 'Maaf, Anda harus login terlebih dahulu');
			redirect(base_url("login"));
		}
    }

    public function index(){
        $id = $this->session->userdata("id");

        $data['title'] = "Profil";
        
        $data['user'] = $this->Arab_model->get_user_by_id($id);
        $kata = $this->Arab_model->get_kata_user_by_id_user($id);
        $kosa_kata = 0;
        foreach ($kata as $kata) {
            if($kata['latihan'] == 2){
                $kosa_kata += $kata['kata'];
            }
        }
        $data['kata'] = $kosa_kata;
        
        $this->load->view("templates/header-user", $data);
        $this->load->view("user/profil", $data);
        $this->load->view("templates/footer-user", $data);
    }

    // edit
        public function edit_user_by_id(){
            $id = $this->input->post("id_user");
            $this->Arab_model->edit_user_by_id($id);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil merubah profil Anda<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect($_SERVER['HTTP_REFERER']);
        }

        public function edit_password(){
            $id = $this->input->post("id_user");
            $this->Arab_model->edit_password($id);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil mengganti password Anda<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect($_SERVER['HTTP_REFERER']);
        }
    // edit

    public function get_user_by_id(){
        $id = $this->input->post("id");
        $data = $this->Arab_model->get_user_by_id($id);
        echo json_encode($data);
    }

    public function get_kata_user_by_id_user(){
        $id = $this->input->post("id");
        $data = $this->Arab_model->get_kata_user_by_id_user($id);
        echo json_encode($data);
    }
}