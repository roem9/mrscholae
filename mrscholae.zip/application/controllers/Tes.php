<?php
class Tes extends CI_CONTROLLER{
    public function __construct(){
        parent::__construct();
        $this->load->model('Arab_model');
    }

    public function index(){
        $data['title'] = "Tes Masuk";
        
        $data['kalimat1'] = [
            [   
                "id" => "0",
                "kalimat" => "Saya memadamkan lampu di pagi hari",
                "arab" => "أَنَا أُطْفِئُ الْمِصْبَاحَ فِيْ الصَّبَاحِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"],
                ]
            ],
            [
                "id" => "1",
                "kalimat" => "Saya menutup jendela di malam hari",
                "arab" => "أَنَا أُغْلِقُ النَّافِذَةَ فِيْ اللَّيْلِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"],
                ]
            ],
            [
                "id" => "2",
                "kalimat" => "Saya membuka pintu menggunakan kunci",
                "arab" => "أَنَا أَفْتَحُ الْبَابَ بِالْمِفْتَاحِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"],
                ]
            ],
            [
                "id" => "3",
                "kalimat" => "Saya tidur di atas kasur",
                "arab" => "أَنَا أَنَامُ عَلَى الْفِرَاشِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "4",
                "kalimat" => "Saya duduk di atas lantai",
                "arab" => "أَنَا أَجْلِسُ عَلَى الْبِلَاطَةِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "5",
                "kalimat" => "Saya menggantungkan cermin di tembok",
                "arab" => "أَنَا أُعَلِّقُ الْمِرْآةَ فِيْ الْجِدَارِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "6",
                "kalimat" => "Saya meletakkan kasur di atas ranjang",
                "arab" => "أَنَا أَضَعُ الْفِرَاشَ عَلَى السَّرِيْرِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"]
                ]
            ]
        ];

        $data['kalimat2'] = [
            [   
                "id" => "0",
                "kalimat" => "Saya keluar dari kelas",
                "arab" => "أَنَا أَخْرُجُ مِنْ الْفَصْلِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "1",
                "kalimat" => "Saya pergi ke masjid",
                "arab" => "أَنَا أَذْهَبُ إلَى الْمَسْجِدِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "2",
                "kalimat" => "Saya membaca buku",
                "arab" => "أَنَا أَقْرَأُ الْكِتَابَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "3",
                "kalimat" => "Saya meminum air",
                "arab" => "أَنَا أَشْرَبُ الْمَاءَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "4",
                "kalimat" => "Saya belajar di rumah",
                "arab" => "أَنَا أَدْرُسُ فِيْ الْبَيْتِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "5",
                "kalimat" => "Saya menulis pelajaran",
                "arab" => "أَنَا أَكْتُبُ الدَّرْسَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "6",
                "kalimat" => "Saya bermain di lapangan",
                "arab" => "أَنَا أَلْعَبُ فِيْ الْمَيْدَانِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ]
        ];
        
        $data['kalimat3'] = [
            [   
                "id" => "0",
                "kalimat" => "Saya membersihkan kamar",
                "arab" => "أَنَا أُنَظِّفُ الْغُرفَةَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "1",
                "kalimat" => "Saya mengetuk pintu",
                "arab" => "أَنَا أَطْرُقُ الْبَابَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "2",
                "kalimat" => "Saya memasak makanan",
                "arab" => "أَنَا أَطْبَخُ الطَّعَامَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "3",
                "kalimat" => "Saya merapikan kasur",
                "arab" => "أَنَا أُرَتِّبُ الْفِرَاشَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "4",
                "kalimat" => "Saya menyalakan lampu",
                "arab" => "أَنَا أُشْعِلُ الْمِصْبَاحَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "5",
                "kalimat" => "Saya menyapu lantai",
                "arab" => "أَنَا أَكْنُسُ الْبِلاَطَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "6",
                "kalimat" => "Saya pergi ke pasar",
                "arab" => "أَنَا أَذْهَبُ إلَى السُّوْقِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ]
        ];

        $data['kalimat4'] = [
            [   
                "id" => "0",
                "kalimat" => "Saya pulang ke rumah",
                "arab" => "أَنَا أَرْجِعُ إلَى الْبَيْتِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "1",
                "kalimat" => "Saya mengumpulkan sampah",
                "arab" => "أَنَا أَجْمَعُ الزُّبَالَةَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "2",
                "kalimat" => "Saya jatuh di kamar mandi",
                "arab" => "أَنَا أَسْقُطُ فِيْ الْحَمَّامِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "1", "jenis" => "huruf"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "3",
                "kalimat" => "Saya menghormati guru",
                "arab" => "أَنَا أَحْتَرِمُ الْمُدَرِّسَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "4",
                "kalimat" => "Saya bertanya kepada guru",
                "arab" => "أَنَا أَسْأَلُ الْمُدَرِّسَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "5",
                "kalimat" => "Saya menabung uang",
                "arab" => "أَنَا أَدَّخِرُ الْفُلُوْسَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "6",
                "kalimat" => "Saya mengajar murid-murid",
                "arab" => "أَنَا أُعَلِّمُ الطُّلَّابَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ]
        ];
        
        $data['kalimat5'] = [
            [   
                "id" => "0",
                "kalimat" => "Saya mengendarai mobil",
                "arab" => "أَنَا أَرْكَبُ السَّيَّارَةَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "1",
                "kalimat" => "Saya memakai pakaian",
                "arab" => "أَنَا أَلْبِسُ الثَّوْبَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "2",
                "kalimat" => "Saya meminta hadiah",
                "arab" => "أَنَا أَطْلُبُ الْهَدِيَّةَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "3",
                "kalimat" => "Saya membakar kayu",
                "arab" => "أَنَا اَحْرُقُ الْخَشَبَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "4",
                "kalimat" => "Saya membagi makanan ke teman-teman",
                "arab" => "أَنَا أُقَسِّمُ الطَّعَامَ إلَى الْأَصْدِقَاءِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "5",
                "kalimat" => "Saya mengambil makanan di dapur",
                "arab" => "أَنَا آخُذُ الطَّعَامَ فِيْ الْمَطْبَخِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "6",
                "kalimat" => "Saya bangun di waktu subuh",
                "arab" => "أَنَا أَسْتَيْقِظُ فِيْ الصُّبْحِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"],
                ]
            ]
        ];
        
        $data['kalimat6'] = [
            [   
                "id" => "0",
                "kalimat" => "Saya berbicara dengan guru",
                "arab" => "أَنَا أَتَكَلَّمُ مَعَ الْمُدَرِّسِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "1",
                "kalimat" => "Saya membawa Al-Quran ke masjid",
                "arab" => "أَنَا اَحْمِلُ الْقُرْآنَ إلَى الْمَسْجِدِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"],
                    ["id" => "3", "jenis" => "huruf"],
                    ["id" => "4", "jenis" => "isim"],
                ]
            ],
            [
                "id" => "2",
                "kalimat" => "Saya membantu guru",
                "arab" => "أَنَا اُسَاعِدُ الْمُدَرِّسَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ],
            [
                "id" => "3",
                "kalimat" => "Saya menghadap ke papan tulis",
                "arab" => "أَنَا اَتَّجِهُ إلَى السَّبُّوْرَةِ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "huruf"],
                    ["id" => "3", "jenis" => "isim"],
                ]
            ],
            [
                "id" => "4",
                "kalimat" => "Saya mendengar suara",
                "arab" => "أَنَا اَسْمَعُ الصَّوْتَ",
                "kata" => [
                    ["id" => "0", "jenis" => "dhomir"],
                    ["id" => "1", "jenis" => "fiil"],
                    ["id" => "2", "jenis" => "isim"]
                ]
            ]
        ];

        $this->load->view("templates/header", $data);
        $this->load->view("page/tesmasuk", $data);
        $this->load->view("templates/footer", $data);
    }

    public function formPendaftaran(){
        $data['title'] = "Form Pendaftaran";
        
        if($this->input->post("hasil")){
            $data_session = array(
                'tes' => "lulus"
				);
 
			$this->session->set_userdata($data_session);
        }

        if($this->session->userdata('tes')){
            $this->load->view("templates/header-login", $data);
            $this->load->view("page/form-pendaftaran", $data);
        } else {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Maaf, Anda harus lulus tes terlebih dahulu sebelum mendaftar<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect("Tes");
        }

        // $this->load->view("templates/footer-user", $data);
    }

    public function add_user(){
        $email = $this->input->post("email", TRUE);
        $cek = $this->Arab_model->get_user_by_email($email);
        if($cek){
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Gagal mendaftarkan akun Anda. email Anda sudah digunakan<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect($_SERVER['HTTP_REFERER']);
        } else {
            $id = $this->Arab_model->get_last_id_user();
            $this->Arab_model->add_user($id);
            $this->session->set_flashdata('pesan', '<div class="alert alert-success alert-dismissible fade show" role="alert">Berhasil mendaftarkan akun Anda<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            redirect("login");
        }

    }

}