<?php
class Latihan_model extends CI_MODEL{
    // get by id
        public function get_all_latihan_by_id_materi_id_user($id, $id_user){
            $this->db->from("latihan");
            $this->db->where("id_materi", $id);
            $this->db->where("id_user", $id_user);
            return $this->db->get()->result_array();
        }
    // get by id

    public function add_latihan(){
        $id = $this->session->userdata("id");
        $latihan = $this->input->post("latihan");
        $id_materi = $this->input->post("id_materi");

        $cek = $this->cek_latihan($id, $latihan);
        
        if($cek == null){
            $data = [
                "latihan" => $latihan,
                "id_materi" => $id_materi,
                "id_user" => $id
            ];
    
            $this->db->insert("latihan", $data);
        }
    }

    public function add_latihan_mufrodat(){
        $id = $this->session->userdata("id");
        $id_tema = $this->input->post("id_tema");
        $latihan = $this->input->post("latihan");

        $cek = $this->cek_latihan_mufrodat($id, $id_tema, $latihan);
        
        if($cek == null){
            $data = [
                "id_tema" => $id_tema,
                "id_user" => $id,
                "latihan" => $latihan
            ];
    
            $this->db->insert("kata_user", $data);
        }
    }

    public function add_materi(){
        $id = $this->session->userdata("id");
        $id_materi = $this->input->post("id_materi");
        $id_materi += 1;

        $cek = $this->cek_materi($id, $id_materi);

        if($cek == null){
            $data = [
                "id_user" => $id,
                "id_materi" => $id_materi
            ];
    
            $this->db->insert("materi_user", $data);
        }
    }

    // other function
        public function cek_latihan($id_user, $latihan){
            $this->db->from("latihan");
            $this->db->where("id_user", $id_user);
            $this->db->where("latihan", $latihan);
            return $this->db->get()->row_array();
        }
        
        public function cek_latihan_mufrodat($id_user, $id_tema, $latihan){
            $this->db->from("kata_user");
            $this->db->where("id_user", $id_user);
            $this->db->where("id_tema", $id_tema);
            $this->db->where("latihan", $latihan);
            return $this->db->get()->row_array();
        }

        public function cek_materi($id_user, $id_materi){
            $this->db->from("materi_user");
            $this->db->where("id_user", $id_user);
            $this->db->where("id_materi", $id_materi);
            return $this->db->get()->row_array();
        }
    // other function
}