
<!-- modal lupa password -->
<div class="modal fade" id="modalLupaPassword" tabindex="-1" role="dialog" aria-labelledby="modalLupaPasswordLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modalLupaPasswordLabel">Lupa Password</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<div class="alert alert-info">
					<i class="fa fa-info-circle text-info"></i> masukkan email Anda. Kami akan mengirimkan link untuk mereset password Anda pada email
				</div>
				<form action="<?= base_url()?>login/lupa_password" method="post">
					<div class="form-group">
						<label for="email">Email</label>
						<input type="email" name="email" id="email" class="form-control form-control-sm" required>
					</div>
					<div class="d-flex justify-content-end">
						<input type="submit" value="Kirim Link" class="btn btn-sm btn-primary">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<!-- modal lupa password -->

<div class="container">
	<!-- Outer Row -->
	<div class="row justify-content-center">
		<div class="col-xl-5 col-lg-5 col-md-5">
			<div class="card o-hidden border-0 shadow-lg my-5">
				<div class="card-body p-0">
					<!-- Nested Row within Card Body -->
					<div class="row">
						<div class="col-lg-12">
							<div class="p-5">
								<div class="text-center">
									<h1 class="h4 text-gray-900 mb-4">أَهْلًا وَ سَهْلًا</h1>
								</div>
									<?php if( $this->session->flashdata('pesan') ) : ?>
											<div class="row">
													<div class="col-12">
														<?=$this->session->flashdata('pesan')?>
													</div>
											</div>
									<?php endif; ?>
									<form action="<?=base_url()?>login/cek_login_user" method="POST">
											<div class="form-group">
											<input type="text" class="form-control form-control-user" placeholder="Enter Email" name="email" required>
											</div>
											<div class="form-group">
											<input type="password" class="form-control form-control-user" placeholder="Password" name="password" required>
											</div>
											<button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
									</form>
									<a href="<?= base_url()?>login/registrasi" class="btn btn-block btn-sm btn-outline-success mt-1">Daftar</a>
									<div class="text-center mt-3"><a data-toggle="modal" href="#modalLupaPassword">Lupa Password?</a></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>