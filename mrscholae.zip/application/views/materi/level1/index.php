        <div class="container">
            <div class="row">
                <?php foreach($materi as $materi) :?>
                    <div class="col-12 col-md-4 mb-3">

                        <?php if($materi['status'] == 'on') :?>
                            <div class="card shadow">
                        <?php else : ?>
                            <div class="card border-danger shadow">
                        <?php endif;?>

                            <div class="card-header"><?= $materi['nama_materi']?></div>
                            <div class="card-body">
                                <div class="container">
                                    <div class="row">
                                        <a href="#TujuanPembelajaran" data-id="<?= $materi['id_materi']?>" data-toggle="modal" class="btn btn-sm btn-info modal-tujuan mr-1 mb-1">Tujuan Pembelajaran</a>
                                        <?php if($materi['status'] == 'on') : ?>
                                            <!-- <a href="<?= base_url()?>level1/materi/<?= strtolower($materi['link'])?>" class="btn btn-sm btn-success mr-1 mb-1">Mulai Belajar</a> -->
                                            <a class="btnMulai btn btn-sm btn-success mr-1 mb-1 text-light" data-id="<?= base_url()?>level1/materi/<?= strtolower($materi['link'])?>">Mulai Belajar</a>
                                        <?php else :?>
                                            <a class="btnError btn btn-sm btn-success mr-1 mb-1 text-light">Mulai Belajar</a>
                                        <?php endif;?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach;?>
            </div>
        </div>
    </div>
</div>

<!-- Modal Tujuan Pembelajaran -->
    <div class="modal fade" id="TujuanPembelajaran" tabindex="-1" role="dialog" aria-labelledby="TujuanPembelajaranLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="TujuanPembelajaranLabel">Tujuan Pembelajaran</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <ul class="list-group">
                        <li class="list-group-item list-group-item-success"><span id="materi"></span></li>
                        <div id="list-tujuan"></div>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">close</button>
                </div>
            </div>
        </div>
    </div>
<!-- Modal Tujuan Pembelajaran -->

<div class="overlay"></div>

<script>
    $(".modal-tujuan").click(function(){
        let id = $(this).data("id");

        $.ajax({
            url: "<?= base_url()?>level1/get_tujuan_by_id_materi",
            method: "POST",
            dataType: "json",
            data: {id: id},
            success: function(data){
                $("#materi").html(data[0].nama_materi)

                var html = '';
                for (let i = 0; i < data.length; i++) {
                    html += ` <li class="list-group-item">`+data[i].tujuan+`</li>`;
                }

                $("#list-tujuan").html(html);
            },
            error: function(xhr, ajaxOptions, thrownError){
                alert(xhr.status);
            }
        })
    })
    
    $(".btnMulai").click(function(){
        let link = $(this).data("id");
        Swal.fire({
            icon: 'info',
            text: 'Sebelum belajar berdoa dulu yaa',
            confirmButtonText: '<a href="'+link+'">Mulai</a>'
        })
    })

    $(".btnError").click(function(){
        Swal.fire(
            'Oopss',
            'pelajari materi sebelumnya dulu yaa, kerjakan latihannya juga. tetap semangat',
            'error'
        )
    })
</script>