    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="form-group">
                    <label for="bahasa">Pilih Bahasa</label>
                    <select name="bahasa" id="bahasa" class="form-control">
                        <option value="">Pilih Bahasa</option>
                        <option value="Baku" selected>Bahasa Baku</option>
                        <option value="Teman">Bahasa Teman</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-12 mb-3">
                <ul class="list-group">
                    <li class="list-group-item list-group-item-danger d-flex justify-content-between">Petunjuk</li>
                    <li class="list-group-item" id="baku">Berikut ini beberapa kata yang dapat Anda gunakan untuk berlatih membentuk fiil mudhori sesuai dengan dhomirnya. Jika Anda telah mengerjakan 15 latihan maka pelajaran selanjutnya akan terbuka. Anda disarankan untuk mengerjakan semua latihan</li>
                    <li class="list-group-item" id="teman">Manteman, Experience is the best teacher. Pada bagian ini ada 30 kata yang bisa digunakan untuk latihan. semangat berlatih. jangan putus asa. pokoknya semangattttttt. semangat. S E M A..... udah ah (-_-). Oh iya kan ada 30 tuh, kalau kebanyakan cukup kerjakan 15 maka pelajaran selanjutnya akan terbuka. Tapi yakin cuma gerjain 15 doang?</li>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-md-12 mb-3">
                <a id="backHome" class="btn btn-sm btn-success text-light"><i class="fa fa-home"></i> Level 1</a>
            </div>
        </div>
        <div class="row">
            <?php foreach($kata as $kata) :?>
                <div class="col-12 col-md-3 mb-3">
                    <div class="card shadow">
                        <div class="card-header"><?= $kata['kata']?></div>
                        <div class="card-body">
                            <div class="container">
                                <div class="row">
                                    <form action="<?= base_url()?>level1/latihan/fiilmudhori" method="post">
                                        <input type="hidden" name="id" value="<?= $kata['id']?>">
                                        <input type="hidden" name="kata" value="<?= $kata['kata']?>">
                                        <input type="hidden" name="latihan" value="<?= $kata['latihan']?>">
                                        <div class="d-flex justify-content-between">
                                            <?php if($kata['status'] == 'on'):?>
                                                <input type="submit" value="Mulai Belajar" class="btn btn-success btn-sm">
                                                <span class="btn btn-sm"><i class="fa fa-check-circle text-success"></i></span>
                                            <?php else :?>
                                                <input type="submit" value="Mulai Belajar" class="btn btn-danger btn-sm">
                                                <span class="btn btn-sm"><i class="fa fa-times-circle text-danger"></i></span>
                                            <?php endif;?>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach;?>
        </div>
      </div>
    </div>
</div>

<div class="overlay"></div>

<script>
    // bahasa
        $("#teman").hide();
        $("#baku").show();
        $("#bahasa").change(function(){
            let value = $(this).val();
            if(value == "Baku"){
                $("#teman").hide();
                $("#baku").show();
            } else if(value == "Teman"){
                $("#teman").show();
                $("#baku").hide();
            }
        })
    // bahasa
    
    $("#backHome").click(function(){
        Swal.fire({
            icon: 'question',
            text: 'yakin akan kembali ke menu utama?',
            showCloseButton: true,
            showCancelButton: true,
            confirmButtonText: '<a href="<?= base_url()?>level1">Ya</a>',
            cancelButtonText: 'Tidak'
        })
    })
</script>