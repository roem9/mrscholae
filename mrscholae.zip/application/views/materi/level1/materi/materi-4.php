        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="form-group">
                        <label for="bahasa">Pilih Bahasa</label>
                        <select name="bahasa" id="bahasa" class="form-control">
                            <option value="">Pilih Bahasa</option>
                            <option value="Baku" selected>Bahasa Baku</option>
                            <option value="Teman">Bahasa Teman</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 mb-3">
                    <ul class="list-group" id="teman">
                        <li class="list-group-item list-group-item-danger d-flex justify-content-between">Pengantar</li>
                        <li class="list-group-item">Okey, Yes. Manteman udah ngafalin 85 kosa kata dalam 42 kalimat. Sadar atau engga (mudah-mudahan sadar) ada beberapa hal yang harus kalian sadari (eh apasih (-_-) ) : </li>
                        <li class="list-group-item">1. Objek (dalam bahasa Arab مَفْعُوْلٌ بِهِ) atau sesuatu yang dikenakan pekerjaan, <b>secara umum</b> harakatnya menjadi <b>fathah</b>. wah iya emang? masa sih? lah iyalah udah sadarkan (-_-) . cek disini yaa <a href="#modalContohObjek" data-toggle="modal" class="ml-1 btn btn-sm btn-success btn-info">cek kuy</a></li>
                        <li class="list-group-item">2. Kata benda, ingat yaa <b>kata benda</b>, sekali lagi <b>kata benda</b>, sekali lagi (udah (-_-) ). Yang berada setelah kata بِ (dengan), فِيْ (di dalam), عَلَى (di atas), مِنْ (dari), مَعَ (dengan), إلَى (ke) <b>secara umum</b> harakatnya menjadi <b>kasrah</b>. waaahh iya? Amazing kan, kaaaannn (-_-) . cek langsung disini yaa, yaa, yaa <a href="#modalContohHuruf" data-toggle="modal" class="ml-1 btn btn-sm btn-info">cek teross</a></li>
                    </ul>
                    <ul class="list-group" id="baku">
                        <li class="list-group-item list-group-item-danger d-flex justify-content-between">Pengantar</li>
                        <li class="list-group-item">Sebelum memulai pembelajaran ada beberapa hal yang perlu Anda ketahui terlebih dahulu</li>
                        <li class="list-group-item">1. Didalam Bahasa Arab, Objek (مَفْعُوْلٌ بِهِ) atau sesuatu yang dikenakan pekerjaan, <b>secara umum</b> harakatnya akan menjadi fathah. Silahkan perhatikan kembali kalimat yang telah Anda hafalkan <a href="#modalContohObjek" data-toggle="modal" class="ml-1 btn btn-sm btn-success btn-info">Disini</a></li>
                        <li class="list-group-item">2. <b>Kata benda</b> yang berada setelah kata بِ (dengan), فِيْ (di dalam), عَلَى (di atas), مِنْ (dari), مَعَ (dengan), إلَى (ke) <b>secara umum</b> harakatnya akan menjadi <b>kasrah</b>. Silahkan perhatikan kembali kalimat yang telah Anda hafalkan <a href="#modalContohHuruf" data-toggle="modal" class="ml-1 btn btn-sm btn-info">Disini</a></li>
                    </ul>
                </div>
            </div>
            <div class="row">

            </div>
            <div class="row">
                <div class="col-12 col-md-12 mb-3">
                    <ul class="list-group">
                        <li class="list-group-item list-group-item-warning">Latihan</li>
                        <?php foreach ($latihan as $i => $latihan) :?>
                            <form action="<?= base_url()?>level1/latihan/menyusunmudhori" method="post">
                                <li class="list-group-item d-flex justify-content-between">
                                    <input type="hidden" name="latihan" value="<?= $latihan['latihan']?>">
                                    <input type="hidden" name="urut" value="<?= $i+1?>">
                                    <?php if($latihan['status'] == 'on'):?>
                                        <input type="submit" value="Latihan <?= $i+1?>" class="btn btn-success btn-sm">
                                        <span class="btn btn-sm"><i class="fa fa-check-circle text-success"></i></span>
                                    <?php else:?>
                                        <input type="submit" value="Latihan <?= $i+1?>" class="btn btn-danger btn-sm">
                                        <span class="btn btn-sm"><i class="fa fa-times-circle text-danger"></i></span>
                                    <?php endif;?>

                                </li>
                            </form>
                        <?php endforeach;?>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-12 mb-3">
                    <a id="backHome" class="btn btn-sm btn-success text-light"><i class="fa fa-home"></i> Level 1</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="overlay"></div>

<!-- kumpulan modal -->
    
    <div class="modal fade" id="modalContohObjek" tabindex="-1" role="dialog" aria-labelledby="modalContohObjekLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalContohObjekLabel">Simak dan Perhatikan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="font-size: 20px">
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَقْرَأُ <span class="text-primary">الْكِتَابَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span> أَنَا أَشْرَبُ <span class="text-primary">الْمَاءَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَكْتُبُ <span class="text-primary">الدَّرْسَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَطْبَخُ <span class="text-primary">الطَّعَامَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَطْرُقُ <span class="text-primary">الْبَابَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُنَظِّفُ <span class="text-primary">الْغُرفَةَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَكْنُسُ <span class="text-primary">الْبِلاَطَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُشْعِلُ <span class="text-primary">الْمِصْبَاحَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُرَتِّبُ <span class="text-primary">الْفِرَاشَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَجْمَعُ <span class="text-primary">الزُّبَالَةَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَدَّخِرُ <span class="text-primary">الْفُلُوْسَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَسْأَلُ <span class="text-primary">الْمُدَرِّسَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَحْتَرِمُ <span class="text-primary">الْمُدَرِّسَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُعَلِّمُ <span class="text-primary">الطُّلَّابَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَطْلُبُ <span class="text-primary">الْهَدِيَّةَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَلْبِسُ <span class="text-primary">الثَّوْبَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَرْكَبُ <span class="text-primary">السَّيَّارَةَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اَحْرُقُ <span class="text-primary">الْخَشَبَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اُسَاعِدُ <span class="text-primary">الْمُدَرِّسَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اَقُصُّ <span class="text-primary">الْقِصَّةَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اَسْمَعُ <span class="text-primary">الصَّوْتَ</span></span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اَحْفَظُ <span class="text-primary">الدَّرْسَ</span></span></li>
                        <li class="list-group-item list-group-item-warning" id="teman-1" style="font-size: 15px">Gimana manteman benarkan? kann? kaaaaaan? ingat-ingat ini yaa!!! Sengaja dikasih warna kuning biar diperhatiin eh wkwk (-_-)</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="modalContohHuruf" tabindex="-1" role="dialog" aria-labelledby="modalContohHurufLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalContohHurufLabel">Simak dan Perhatikan</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" style="font-size: 20px">
                    <ul class="list-group">
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُطْفِئُ <span class="text-primary">الْمِصْبَاحَ</span> <span class="text-danger">فِي</span> الصَّبَاحِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُغْلِقُ <span class="text-primary">النَّافِذَةَ</span> <span class="text-danger">فِى</span> اللَّيْلِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَفْتَحُ <span class="text-primary">الْبَابَ</span> <span class="text-danger">بِا</span>لْمِفْتَاحِ </span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَنَامُ <span class="text-danger">عَلَى</span> الْفِرَاشِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَجْلِسُ <span class="text-danger">عَلَى</span> الْبِلَاطَةِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُعَلِّقُ <span class="text-primary">الْمِرْآةَ</span> <span class="text-danger">فِي</span> الْجِدَارِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَضَعُ <span class="text-primary">الْفِرَاشَ</span> <span class="text-danger">عَلَى</span> السَّرِيْرِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَخْرُجُ <span class="text-danger">مِنَ</span> الْفَصْلِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَذْهَبُ <span class="text-danger">اِلَى</span> الْمَسْجِدِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span> أَنَا أَدْرُسُ <span class="text-danger">فِيْ</span> الْبَيْتِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَلْعَبُ <span class="text-danger">فِيْ</span> الْمَيْدَانِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَذْهَبُ <span class="text-danger">إِلَى</span> السُّوْقِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَسْقُطُ <span class="text-danger">فِى</span> الْحَمَّامِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَرْجِعُ <span class="text-danger">إِلَى</span> الْبَيْتِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا آخُذُ <span class="text-primary">الطَّعَامَ</span> <span class="text-danger">فِي</span> الْمَطْبَخِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أُقَسِّمُ <span class="text-primary">الطَّعَامَ</span> <span class="text-danger">إِلَى</span> الْأَصْدِقَاءِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَسْتَيْقِظُ <span class="text-danger">فِي</span> الصُّبْحِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اَحْمِلُ <span class="text-primary">الْقُرْآنَ</span> <span class="text-danger">إِلَى</span> الْمَسْجِدِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا أَتَكَلَّمُ <span class="text-danger">مَعَ</span> الْمُدَرِّسِ</span></li>
                        <li class="list-group-item d-flex justify-content-end"><span>أَنَا اَتَّجِهُ <span class="text-danger">إِلَى</span> السَّبُّوْرَةِ</span></li>
                        <li class="list-group-item list-group-item-warning" id="teman-2" style="font-size: 15px">Yang ini juga diperhatiin yaa manteman, jangan dia mulu yang diperhatiin eh wkwk</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
                </div>
            </div>
        </div>
    </div>
    <!-- <br>huruf b bisa bersambung yaa manteman -->
<!-- kumpulan modal -->

<script>
    $("#teman").hide();
    $("#teman-1").hide();
    $("#teman-2").hide();
    $("#baku").show();
    $("#bahasa").change(function(){
        let value = $(this).val();
        if(value == "Baku"){
            $("#teman").hide();
            $("#baku").show();
        } else if(value == "Teman"){
            $("#teman").show();
            $("#baku").hide();
            $("#teman-1").show();
            $("#teman-2").show();
        }
    })

    $("#backHome").click(function(){
        Swal.fire({
            icon: 'question',
            text: 'yakin akan kembali ke menu utama?',
            showCloseButton: true,
            showCancelButton: true,
            confirmButtonText: '<a href="<?= base_url()?>level1">Ya</a>',
            cancelButtonText: 'Tidak'
        })
    })
</script>