<?php
    $dhomir = ["هُوَ","هُمَا","هُمْ","هِيَ","هُنَّ","أَنْتَ","أَنْتُمَا","أَنْتُمْ","أَنْتِ","أَنْتُنَّ","أَنَا","نَحْنُ"];
    $huruf = ["بِ", "فِيْ", "عَلَى", "مِنْ", "مَعَ", "إلَى"];
    // function
        function awal($kata, $awal){
            $text = substr($kata, 0, 2);
            $text = substr($kata, 2);
            $text = $awal . $text;
            return $text;
        }

        function akhir($kata, $akhir){
            $data = strlen($kata);
            $text = substr($kata, 0, $data-2);
            $text = $text . $akhir;
            return $text;
        }

        function huwa($kata){
            return $kata;
        }
        
        function huma_lk($kata){
            $text = akhir($kata, "َانِ");
            return $text;
        }

        function hum($kata){
            $text = akhir($kata, "ُوْنَ");
            return $text;
        }

        // hiya dan anta
        function hiya($kata){
            $text = awal($kata, "ت");
            return $text;
        }

        // huma pr dan antuma
        function huma_pr($kata){
            $text = awal($kata, "ت");
            $text = akhir($text, "َانِ");
            return $text;
        }

        function hunna($kata){
            $text = akhir($kata, "ْنَ");
            return $text;
        }

        function antum($kata){
            $text = awal($kata, "ت");
            $text = akhir($text, "ُوْنَ");
            return $text;
        }

        function anti($kata){
            $text = awal($kata, "ت");
            $text = akhir($text,"ِيْنَ");
            return $text;
        }

        function antunna($kata){
            $text = awal($kata, "ت");
            $text = akhir($text, "ْنَ");
            return $text;
        }

        function ana($kata){
            $text = awal($kata, "أ");
            return $text;
        }
        
        function nahnu($kata){
            $text = awal($kata, "ن");
            return $text;
        }
    // function

    function mudhori($kata){
        return [huwa($kata),huma_lk($kata),hum($kata),hiya($kata),huma_pr($kata),hunna($kata),antum($kata),anti($kata),antunna($kata),ana($kata),nahnu($kata)];
    }

    // function isim
        function dhommah($kata){
            return akhir($kata, "ُ");
        }
        
        function fathah($kata){
            return akhir($kata, "َ");
        }

        function kasrah($kata){
            return akhir($kata, "ِ");
        }
    // function isim
    
    function isim($kata){
        return [dhommah($kata), fathah($kata), kasrah($kata)];
    }
?>
        <div class="container">
            
            <div class="row">
                <div class="col-12 col-md-12 mb-3">
                    <a id="backHome" class="btn btn-sm btn-success text-light"><i class="fa fa-arrow-left"></i> Kembali</a>
                </div>
            </div>
            <?php if($kalimat != null):?>
                <div class="row">
                    <div class="col-12 col-md-12 mb-3">
                        <ul class="list-group" id="teman">
                            <li class="list-group-item list-group-item-danger d-flex justify-content-between">Latihan <?= $urut?></li>
                            <!-- <li class="list-group-item"> -->
                            <!-- </li> -->
                        </ul>
                    </div>
                    <?php foreach ($kalimat as $i => $kalimat) :
                        $urut = $i + 1;
                    ?>
                        <div class="col-12 col-md-12 mb-3">
                            <div class="form-group">
                                <label for="<?=$i?>"><?= $urut?>. <?= $kalimat['kalimat']?></label>
                                <input type="hidden" name="kunci<?=$i?>" value="<?= $kalimat['arab']?>">
                                <input type="hidden" name="j<?= $i?>" id="jawaban<?=$i?>">
                                <h5 class="text-right" id="j<?=$i?>"></h5>
                                <div id="select<?=$i?>">
                                    <?php foreach ($kalimat['kata'] as $x => $kata) :?>
                                        <?php if($kata['jenis'] == 'huruf'):?>
                                            <select name="<?= $i.$x?>" id="<?= $i.$x?>" class="form-control form-control-lg mb-2">
                                                <option value="">Pilih Jawaban</option>
                                                <?php foreach ($huruf as $data) :?>
                                                    <option value="<?= $data?>"><?= $data?></option>
                                                <?php endforeach;?>
                                            </select>
                                        <?php elseif($kata['jenis'] == 'mudhori'):?>
                                            <?php $mudhori = mudhori($kata['kata']);?>
                                            <select name="<?= $i.$x?>" id="<?= $i.$x?>" class="form-control form-control-lg mb-2">
                                                <option value="">Pilih Jawaban</option>
                                                <?php foreach ($mudhori as $data) :?>
                                                    <option value="<?= $data?>"><?= $data?></option>
                                                <?php endforeach;?>
                                            </select>
                                        <?php elseif($kata['jenis'] == 'dhomir'):?>
                                            <select name="<?= $i.$x?>" id="<?= $i.$x?>" class="form-control form-control-lg mb-2">
                                                <option value="">Pilih Jawaban</option>
                                                <?php foreach ($dhomir as $data) :?>
                                                    <option value="<?= $data?>"><?= $data?></option>
                                                <?php endforeach;?>
                                            </select>
                                        <?php elseif($kata['jenis'] == 'isim'):?>
                                            <?php $isim = isim($kata['kata']);?>
                                            <select name="<?= $i.$x?>" id="<?= $i.$x?>" class="form-control form-control-lg mb-2">
                                                <option value="">Pilih Jawaban</option>
                                                <?php foreach ($isim as $data) :?>
                                                    <option value="<?= $data?>"><?= $data?></option>
                                                <?php endforeach;?>
                                            </select>
                                        <?php endif;?>
                                    <?php endforeach;?>
                                    <a class="btn btn-block btn-sm btn-info text-light cek" data-id="<?= $i?>|<?= COUNT($kalimat['kata'])?>">Cek Jawaban</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach;?>
                </div>
                <div class="row">
                    <form action="<?= base_url()?>latihan/latihan4" method="post" id="latihan">
                        <input type="hidden" name="latihan" value="<?= $latihan?>">
                        <input type="hidden" name="id_materi" value="4">
                    </form>
                    <div class="col-12 col-md-12 mb-3">
                        <a id="simpanJawaban" data-id="<?= COUNT($kalimat['kata'])?>" class="btn btn-block btn-primary text-light">Simpan Jawaban</a>
                    </div>
                </div>
            <?php endif;?>
        </div>
    </div>
</div>

<div class="overlay"></div>

<script>
    $("#simpanJawaban").click(function(){
        let count = $(this).data("id");
        let benar = 1;
        for (let i = 0; i < count; i++) {
            cek = $("input[name='j"+i+"']").val();
            if(cek != 'betul'){
                benar = 0;
            }
        }
        if(benar == 0){
            Swal.fire({
                icon: 'error',
                title: 'oppss',
                text: 'ada soal yang belum terjawab, dijawab dulu yaa'
            })
        } else {
            Swal.fire({
                text: "selamat! semua jawabanmu benar",
                icon: 'success',
                confirmButtonText: 'Simpan',
            }).then((result) => {
                if (result.value) {
                    $('#latihan').submit();
                }
            })
        }
    })

    $("#backHome").click(function(){
        Swal.fire({
            icon: 'question',
            text: 'pekerjaan Anda tidak akan tersimpan, yakin akan kembali?',
            showCloseButton: true,
            showCancelButton: true,
            confirmButtonText: '<a href="<?= base_url()?>level1/materi/keempat">Ya</a>',
            cancelButtonText: 'Tidak'
        })
    })

    $(".cek").click(function(){
        let data = $(this).data("id");
        data = data.split("|");
        let id = data[0];
        let total = data[1];

        let html = '';
        for (let i = 0; i < total; i++) {
            if(i == total-1 || $("#"+id+""+i).val() == "بِ"){
                html += $("#"+id+""+i).val();
            } else {
                html += $("#"+id+""+i).val()+' ';
            }
        }
        
        console.log(html)

        if(html == $("input[name='kunci"+id+"']").val()){
            Swal.fire({
                text: "!أَحْسَنْتَ",
                icon: 'success',
            }).then((result) => {
                if (result.value) {
                    $("#j"+id).html(html);
                    $("#jawaban"+id).val("betul");
                    $("#select"+id).hide();
                }
            })
        }else {
            Swal.fire({
                icon: 'error',
                text: 'ada yang salah, coba lagi yaa'
            })
        }
    })
</script>