        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="alert alert-warning"><i class="fa fa-exclamation-circle text-warning"></i> Maaf materi ini belum bisa Anda pelajari. Silahkan pelajari materi lain <a href="<?= base_url()?>level1" class="btn btn-sm btn-info">disini</a></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="overlay"></div>